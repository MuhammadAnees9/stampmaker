<?php
session_start();
include "dbConfig.php";
$text = $_POST["text"];
$to = "";
$from = $_SESSION["email"];
$subject = "Concern Or Suggestion";
$sql = "SELECT adminmail FROM settings";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
   $to = $row["adminmail"];
  }
}
$message = $text;

// $message ="Click below link to confirm your account <br> <a href='http://localhost/StampMaker%20Super%20Final/StampMaker/register.php?id=8'>Click Here</a>";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
 
// Create email headers
$headers .= 'From: '.$from."\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
echo json_encode(array("abc"=>'done'));
?>